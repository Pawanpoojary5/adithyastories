import { Component, lazy, Suspense, useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowDown, ArrowRight } from 'lucide-react'
import Media from './Media.jsx'
import SectionLink from './SectionLink.jsx'
import { site } from '../data/site.js'
import { storyPhotos } from '../data/content.js'

const HeroScene = lazy(() => import('./HeroScene.jsx'))

function hasWebGL() {
  try {
    const c = document.createElement('canvas')
    return !!(c.getContext('webgl2') || c.getContext('webgl'))
  } catch {
    return false
  }
}

// If WebGL crashes, the CSS glow behind the canvas stays as the fallback.
class SceneBoundary extends Component {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  render() {
    return this.state.failed ? null : this.props.children
  }
}

/* >>> CHANGED: pinned scroll story.
   P = 0..1 over the pinned height.
   0.00-0.26  camera pushes in to the lens (HeroScene reads progress)
   0.20-0.34  shutter flash
   0.30-0.88  photos print out one by one
   0.88-1.00  hold with the "view portfolio" call to action */
const N = storyPhotos.length
const INTRO_END = 0.3
const STAGE_END = 0.88
const TILT = [-2.2, 1.8, -1.2, 2.4, -1.8, 1.4]
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v))
const easeOut = (t) => 1 - Math.pow(1 - t, 3)
const easeIO = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)
const pad = (n) => String(n).padStart(2, '0')

function placeCard(el, i, k, cur) {
  const dir = i % 2 === 0 ? -1 : 1
  const tilt = TILT[i % TILT.length]
  const e = clamp((k - i) / 0.7) // printing
  const b = clamp(k - (i + 1)) // pushed back by the next photo
  const b2 = clamp(k - (i + 2)) // two photos back
  let x = 0, y = 0, s = 1, rot = tilt, op = 1, br = 1, bl = 0

  if (k < i) {
    op = 0
    y = 62
  } else if (e < 1) {
    const t = easeOut(e)
    y = (1 - t) * 62
    s = 0.84 + 0.16 * t
    rot = tilt + (1 - t) * -9 * dir
    op = clamp(e * 2.4)
    br = 1 + (1 - t) * 1.6
    bl = (1 - t) * 10
  }
  if (b > 0) {
    const t = easeIO(b)
    x = dir * t * 26
    y = -t * 3
    s = 1 - t * 0.2
    rot = tilt + dir * t * 8
    op = 1 - t * 0.5 - b2 * 0.5
    br = 1 - t * 0.35
  }

  el.style.transform = `translate(-50%, -50%) translate3d(${x}vw, ${y}vh, 0) rotate(${rot}deg) scale(${s})`
  el.style.opacity = String(clamp(op))
  el.style.visibility = op <= 0.01 ? 'hidden' : 'visible'
  el.style.filter = bl > 0.05 || br !== 1 ? `blur(${bl}px) brightness(${br})` : ''
  el.style.zIndex = String(10 + i)
  el.style.pointerEvents = i === cur && op > 0.9 ? 'auto' : 'none'
  el.tabIndex = i === cur ? 0 : -1
}

export default function Hero() {
  const wrap = useRef(null)
  const canvasBox = useRef(null)
  const copy = useRef(null)
  const cue = useRef(null)
  const flash = useRef(null)
  const stage = useRef(null)
  const cards = useRef([])
  const progress = useRef(0)

  const [webgl] = useState(hasWebGL)
  const [reduced] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  const [inView, setInView] = useState(true)
  const [early, setEarly] = useState(true)
  const [ready, setReady] = useState(false)
  const [idx, setIdx] = useState(0)
  const [phase, setPhase] = useState('intro')

  // Pause 3D rendering when the hero is off-screen or after the flash.
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => setInView(e.isIntersecting), { threshold: 0 })
    if (wrap.current) io.observe(wrap.current)
    return () => io.disconnect()
  }, [])

  useEffect(() => {
    if (reduced) return
    let raf = 0
    let lastIdx = -1
    let lastPhase = 'intro'
    let lastEarly = true

    const update = () => {
      raf = 0
      const w = wrap.current
      if (!w) return
      const r = w.getBoundingClientRect()
      const total = Math.max(1, r.height - window.innerHeight)
      const P = clamp(-r.top / total)
      progress.current = P

      if (copy.current) {
        const c = clamp(P / 0.09)
        copy.current.style.opacity = String(1 - c)
        copy.current.style.transform = `translateY(${-c * 40}px)`
      }
      if (cue.current) cue.current.style.opacity = String(1 - clamp(P / 0.04))
      if (canvasBox.current) canvasBox.current.style.opacity = P > 0.26 ? String(1 - clamp((P - 0.265) / 0.045)) : ''
      if (flash.current) flash.current.style.opacity = String(Math.pow(clamp(1 - Math.abs(P - 0.27) / 0.075), 1.4))

      const so = clamp((P - 0.27) / 0.05)
      if (stage.current) {
        stage.current.style.opacity = String(so)
        stage.current.style.visibility = so > 0 ? 'visible' : 'hidden'
      }

      const s = clamp((P - INTRO_END) / (STAGE_END - INTRO_END))
      const k = s * (N - 0.3)
      const cur = clamp(Math.floor(k), 0, N - 1)
      cards.current.forEach((el, i) => el && placeCard(el, i, k, cur))

      const ph = P > STAGE_END - 0.03 ? 'end' : P > 0.27 ? 'stage' : 'intro'
      if (cur !== lastIdx) { lastIdx = cur; setIdx(cur) }
      if (ph !== lastPhase) { lastPhase = ph; setPhase(ph) }
      const e = P < 0.34
      if (e !== lastEarly) { lastEarly = e; setEarly(e) }
    }
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(update) }

    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [reduced])

  const shot = storyPhotos[idx]

  return (
    <>
      <section className={`story${reduced ? ' story--static' : ''}`} ref={wrap} aria-label="Introduction and photo story">
        <span id="photos" className="story__anchor" aria-hidden="true" />
        <div className="story__stick">
          <div className="hero">
            <div className="hero__frame">
              <div className="hero__glow" aria-hidden="true" />

              {webgl && (
                <div className={`hero__canvas${ready ? ' is-ready' : ''}`} ref={canvasBox} aria-hidden="true">
                  <SceneBoundary>
                    <Suspense fallback={null}>
                      <HeroScene active={inView && early} onReady={() => setReady(true)} progress={reduced ? undefined : progress} />
                    </Suspense>
                  </SceneBoundary>
                </div>
              )}

              <div className="hero__shade" aria-hidden="true" />

              <div className="hero__copy" ref={copy}>
                <h1 className="hero__title">
                  <span className="line"><span style={{ '--i': 0 }}>More Than</span></span>
                  <span className="line"><span style={{ '--i': 1 }}>Photos</span></span>
                  <span className="line"><span style={{ '--i': 2 }}>It&rsquo;s Your Story</span></span>
                </h1>
                <p className="hero__intro">{site.tagline}</p>
                <a href="#photos" className="btn-explore">
                  <span className="btn-explore__icon"><ArrowRight size={16} /></span>
                  Explore
                </a>
              </div>

              <p className="hero__scroll" ref={cue} aria-hidden="true"><span />Scroll</p>

              {!reduced && (
                <>
                  <div className="stage grain" ref={stage} role="region" aria-label="Photo story">
                    <div className="stage__bg" aria-hidden="true" />

                    <div className="vf" aria-hidden="true">
                      <i /><i /><i /><i />
                      <p className="mono vf__rec"><b /> REC</p>
                      <p className="mono vf__read">{shot.exif}</p>
                    </div>

                    <div className="stage__cards">
                      {storyPhotos.map((p, i) => (
                        <Link key={p.to} to={p.to} className="shot" ref={(el) => (cards.current[i] = el)} aria-label={`${p.title}, ${p.place}. Open story`}>
                          <span className="shot__img"><Media src={p.src} hue={p.hue} alt={p.title} /></span>
                          <span className="shot__cap"><b>{p.title}</b><small>{p.place}</small></span>
                        </Link>
                      ))}
                    </div>

                    <div className="stage__cap">
                      <p className="mono">Frame {pad(idx + 1)} / {pad(N)}</p>
                      <Link to={shot.to}>Open this story <ArrowRight size={14} /></Link>
                    </div>

                    <ol className="stage__ticks" aria-hidden="true">
                      {storyPhotos.map((p, i) => <li key={p.to} className={i <= idx ? 'on' : ''} />)}
                    </ol>

                    <a href="#reels" className="stage__skip">Skip to reels <ArrowDown size={14} /></a>
                    <Link to="/portfolio" className={`stage__all${phase === 'end' ? ' is-end' : ''}`}>
                      {phase === 'end' ? 'Want to see more? Visit the portfolio' : 'View full portfolio'} <ArrowRight size={16} />
                    </Link>
                  </div>
                  <div className="flash" ref={flash} aria-hidden="true" />
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {reduced && (
        <section className="storygrid" aria-label="Selected photos">
          <ul>
            {storyPhotos.map((p) => (
              <li key={p.to}>
                <Link to={p.to}>
                  <span className="storygrid__img"><Media src={p.src} hue={p.hue} alt={p.title} /></span>
                  <b>{p.title}</b>
                  <small>{p.place}</small>
                </Link>
              </li>
            ))}
          </ul>
          <SectionLink to="/portfolio" kicker="Want to see more?">Visit the portfolio</SectionLink>
        </section>
      )}
    </>
  )
}